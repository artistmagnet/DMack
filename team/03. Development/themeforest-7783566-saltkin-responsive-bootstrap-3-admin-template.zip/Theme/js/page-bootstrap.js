$(function() {

	"use strict";

	// Megamenu
	$( '#dl-menu' ).dlmenu();

})